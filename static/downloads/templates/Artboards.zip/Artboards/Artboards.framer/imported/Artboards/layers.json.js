window.__imported__ = window.__imported__ || {};
window.__imported__["Artboards/layers.json.js"] = [
  {
    "maskFrame" : null,
    "id" : "B0348D24-2CA5-4A32-ABD5-F7C96EF1227A",
    "visible" : true,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "467D259F-657A-4BEC-B60C-B8649B3A5542",
        "visible" : true,
        "children" : [
          {
            "maskFrame" : null,
            "id" : "EA2E254D-4F05-45F5-B120-33C145CE7923",
            "visible" : true,
            "children" : [
              {
                "maskFrame" : null,
                "id" : "A86820BD-4D5F-44EF-AEBB-21FEEF30391A",
                "visible" : true,
                "children" : [

                ],
                "image" : {
                  "path" : "images\/statusBar-A86820BD-4D5F-44EF-AEBB-21FEEF30391A.png",
                  "frame" : {
                    "y" : 11,
                    "x" : 17,
                    "width" : 726,
                    "height" : 20
                  }
                },
                "imageType" : "png",
                "layerFrame" : {
                  "y" : 11,
                  "x" : 17,
                  "width" : 726,
                  "height" : 20
                },
                "name" : "statusBar"
              }
            ],
            "image" : {
              "path" : "images\/navBar-EA2E254D-4F05-45F5-B120-33C145CE7923.png",
              "frame" : {
                "y" : 0,
                "x" : 0,
                "width" : 750,
                "height" : 128
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 0,
              "x" : 0,
              "width" : 750,
              "height" : 128
            },
            "name" : "navBar"
          },
          {
            "maskFrame" : null,
            "id" : "C68015F6-FCB5-4449-872A-1D21349150A1",
            "visible" : true,
            "children" : [

            ],
            "image" : {
              "path" : "images\/contentA-C68015F6-FCB5-4449-872A-1D21349150A1.png",
              "frame" : {
                "y" : 127,
                "x" : 0,
                "width" : 750,
                "height" : 1207
              }
            },
            "imageType" : "png",
            "layerFrame" : {
              "y" : 127,
              "x" : 0,
              "width" : 750,
              "height" : 1207
            },
            "name" : "contentA"
          }
        ],
        "image" : {
          "path" : "images\/screen-467D259F-657A-4BEC-B60C-B8649B3A5542.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "screen"
      }
    ],
    "image" : {
      "path" : "images\/artboardA-B0348D24-2CA5-4A32-ABD5-F7C96EF1227A.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "artboardA"
  },
  {
    "maskFrame" : null,
    "id" : "1DFB7B5B-43D4-4F70-B722-131A68A0AEA1",
    "visible" : false,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "1759C69D-10E4-4D76-8D94-1752671A7207",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/contentB-1759C69D-10E4-4D76-8D94-1752671A7207.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "contentB"
      }
    ],
    "image" : {
      "path" : "images\/artboardB-1DFB7B5B-43D4-4F70-B722-131A68A0AEA1.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "artboardB"
  },
  {
    "maskFrame" : null,
    "id" : "9BF3B1B8-D30E-4CF6-A19E-9B2CD7D96C52",
    "visible" : false,
    "children" : [
      {
        "maskFrame" : null,
        "id" : "D0549DF3-DE90-42ED-93DA-4F9AC49D75D3",
        "visible" : true,
        "children" : [

        ],
        "image" : {
          "path" : "images\/contentC-D0549DF3-DE90-42ED-93DA-4F9AC49D75D3.png",
          "frame" : {
            "y" : 0,
            "x" : 0,
            "width" : 750,
            "height" : 1334
          }
        },
        "imageType" : "png",
        "layerFrame" : {
          "y" : 0,
          "x" : 0,
          "width" : 750,
          "height" : 1334
        },
        "name" : "contentC"
      }
    ],
    "image" : {
      "path" : "images\/artboardC-9BF3B1B8-D30E-4CF6-A19E-9B2CD7D96C52.png",
      "frame" : {
        "y" : 0,
        "x" : 0,
        "width" : 750,
        "height" : 1334
      }
    },
    "imageType" : "png",
    "layerFrame" : {
      "y" : 0,
      "x" : 0,
      "width" : 750,
      "height" : 1334
    },
    "name" : "artboardC"
  }
]